// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; 
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; 
import 'package:caglayanbozamobil/services/auth_service.dart';
import 'package:caglayanbozamobil/services/database_service.dart';
import 'package:caglayanbozamobil/services/notification_service.dart';

import 'package:caglayanbozamobil/models/app_user.dart';
import 'package:caglayanbozamobil/models/market.dart';
import 'package:caglayanbozamobil/screens/add_batch_screen.dart';
import 'package:caglayanbozamobil/screens/market_detail_screen.dart';

/// Ana Ekran (Home Screen)
/// Uygulamanın açılış sayfasıdır. Market listesini gösterir ve
/// kullanıcıyı ilgili marketin detayına yönlendirir.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DatabaseService _dbService = DatabaseService();
  final AuthService _authService = AuthService();

  Map<String, String> _marketNames = {}; // Market ID -> İsim
  Map<String, String> _productNames = {}; // Ürün ID -> İsim
  List<Market> _availableMarkets = []; // Market Listesi

  final Color _primaryBlue = const Color(0xFF0F4C81); 
  final Color _accentGold = const Color(0xFFBE9658); 

  @override
  void initState() {
    super.initState();
    _loadNames(); 
    // Bildirim servisini, UI çizildikten sonra başlat
    WidgetsBinding.instance.addPostFrameCallback((_) {
      NotificationService().init();
    });
  }

  // Veritabanından Market ve Ürün bilgilerini çek
  void _loadNames() async {
    try {
      final List<Market> markets = await _dbService.getMarketsList();
      
      // SIRALAMA: 'Çağlayan' içerenler en üste, diğerleri A'dan Z'ye
      markets.sort((a, b) {
        final aName = a.name.toLowerCase();
        final bName = b.name.toLowerCase();
        final aIsCaglayan = aName.contains('çağlayan') || aName.contains('caglayan');
        final bIsCaglayan = bName.contains('çağlayan') || bName.contains('caglayan');

        if (aIsCaglayan && !bIsCaglayan) return -1;
        if (!aIsCaglayan && bIsCaglayan) return 1;
        return aName.compareTo(bName);
      });

      _availableMarkets = markets; 
      _marketNames = {for (var market in markets) market.id: market.name};

      final products = await _dbService.getProductsList();
      _productNames = {for (var product in products) product.id: product.name};

      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("Adları yükleme hatası: $e");
      if (mounted) {
        setState(() {
          _marketNames = {};
          _productNames = {};
          _availableMarkets = [];
        });
      }
    }
  }

  // Web Linklerini Açmak İçin
  Future<void> _launchURL(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $url');
      if (mounted) {
         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Link açılamadı: $url")));
      }
    }
  }

  // Yeni Stok Ekleme (Admin)
  void _navigateToAddBatchScreen() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddBatchScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AppUser?>(
      stream: _authService.appUser, 
      builder: (context, userSnapshot) {
        // Yükleniyor VEYA veriler henüz gelmediyse bekle
        if (userSnapshot.connectionState == ConnectionState.waiting ||
            (_marketNames.isEmpty && _availableMarkets.isEmpty)) { // Hata durumunda sonsuz loading olmasın diye check güncellendi
           // Veri yoksa veya bekliyorsak loading göster (Ancak hata durumunu handle ettiğimiz için sonsuz dönmez)
           if (userSnapshot.connectionState == ConnectionState.waiting) {
             return const Scaffold(body: Center(child: CircularProgressIndicator()));
           }
           // Eğer yükleme bitti ama liste boşsa devam et (aşağıda boş uyarısı verir)
        }

        final isManager = userSnapshot.data?.isManager ?? false;

        return Scaffold(
          appBar: AppBar(
            backgroundColor: _primaryBlue,
            iconTheme: const IconThemeData(color: Colors.white),
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: Colors.white,
                    backgroundImage: const AssetImage('assets/images/logo.png'),
                    onBackgroundImageError: (_, __) => const Icon(Icons.error),
                  ),
                ),
                const SizedBox(width: 10),
                const Text('Çağlayan Boza', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ],
            ),
            actions: [
              if (isManager)
                IconButton(
                  icon: const Icon(Icons.add_circle, color: Colors.white),
                  onPressed: _navigateToAddBatchScreen,
                ),
              IconButton(
                icon: const Icon(Icons.exit_to_app, color: Colors.white),
                onPressed: () async {
                  await _authService.signOut();
                },
              ),
            ],
          ),
          body: Column(
            children: [
              // Market Listesi
              Expanded(
                child: _availableMarkets.isEmpty
                    ? const Center(child: Text('Henüz tanımlı market yok.'))
                    : ListView.builder(
                        padding: const EdgeInsets.only(top: 10),
                        itemCount: _availableMarkets.length,
                        itemBuilder: (context, index) {
                          final market = _availableMarkets[index];
                          return Card(
                            elevation: 4, 
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              leading: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: _primaryBlue.withOpacity(0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(Icons.store, color: _accentGold, size: 30),
                              ),
                              title: Text(
                                market.name,
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: _primaryBlue),
                              ),
                              subtitle: const Text('Stok detayları için dokunun'),
                              trailing: Icon(Icons.arrow_forward_ios, color: _accentGold, size: 18),
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(builder: (context) => MarketDetailScreen(market: market)),
                                );
                              },
                            ),
                          );
                        },
                      ),
              ),
              // Alt Bilgi (Footer) - İletişim Butonları
              Container(
                padding: const EdgeInsets.all(16.0),
                color: Colors.grey.shade100,
                child: Column(
                  children: [
                    const Text("Bizi Takip Edin", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton.icon(
                          onPressed: () => _launchURL('https://www.caglayanboza.com'),
                          icon: const Icon(Icons.language),
                          label: const Text('Web Sitemiz'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _primaryBlue,
                            foregroundColor: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 15),
                        ElevatedButton.icon(
                          onPressed: () => _launchURL('https://www.instagram.com/caglayanboza/'),
                          icon: const FaIcon(FontAwesomeIcons.instagram, color: Colors.white),
                          label: const Text('Instagram'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFE1306C),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).padding.bottom + 20),
            ],
          ),
        );
      },
    );
  }
}
